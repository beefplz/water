package org.capstone.water.repository.entity.watertank;

/*
@Entity
@Table(name = "watertank")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Watertank {
    @Id
    @Column(name = "fcid")
    private String fcid;

    private String fcn;

}
*/