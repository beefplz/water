package org.capstone.water.repository.entity.watertank;

/*
public interface WatertankRepository extends JpaRepository<Watertank, String> {
    //Watertank findFirstByFcid(String fcid);

    //Watertank findlById(String strings);

}
*/