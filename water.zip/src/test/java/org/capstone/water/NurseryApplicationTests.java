package org.capstone.water;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NurseryApplicationTests {

	@Test
	void contextLoads() {
	}

}
